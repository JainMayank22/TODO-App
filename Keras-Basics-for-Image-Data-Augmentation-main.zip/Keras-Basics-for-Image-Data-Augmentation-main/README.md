# Keras Basics for Image Data
