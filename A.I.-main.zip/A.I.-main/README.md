# AI
Assignments on Max Connect 4, Wumpus World, Probabilities and Bayesian Networks.
