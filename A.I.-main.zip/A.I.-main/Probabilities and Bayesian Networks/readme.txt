Follow these steps to run the code of compute_a_posteriori.py 

	Execute them by following command :
	python compute_a_posteriori [observations]
	ex: python compute_a_posteriori.py CLCLCLCLLCCLLCL

Follow these steps to run the code of bnet.py:

	Execute them by following command :
	python bnet.py [event1] [event2] .... given [observation1] [observation2]...
	or
        python bnet.py [event1] [event2]
	ex: python bnet.py Bf At Mt