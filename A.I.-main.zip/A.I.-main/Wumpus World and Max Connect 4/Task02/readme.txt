Assignment 3
UTA ID:	1001761066
Net ID:	maj1066

Python 2.7

How to run code	: Use following command on Omega to run the program :
python check_true_false.py [wumpus_rules.txt] [additional_knowledge.txt] [statement.txt]

example: python check_true_false.py wumpus_rules.txt additional_knowledge.txt statement.txt


