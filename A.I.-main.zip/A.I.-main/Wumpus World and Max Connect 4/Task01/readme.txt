AI Assignment 3
UTA ID: 1001761066
NET ID: maj1066


Task 1:
How to run the code:
The code can be compiled and executed as follows:

$python maxconnect4.py interactive inputfile.txt computer-next/human-next depth_level for Interactive Mode and
$python maxconnect4.py one-move inputfile.txt outputfile.txt depth_level for One-Move Mode

Reference: https://www.youtube.com/watch?v=XpYz-q1lxu8




